#pragma once
#include "Point.h"
#include "Color.h"
#include "MyShape.h"

namespace macs262_labs{
class MyLine : public MyShape
{
public:
	MyLine(void): MyShape(point1,point2,color) {};
	MyLine(const MyLine* source); 
	~MyLine(void);

	void draw(System::Drawing::Graphics^g) ;
	MyShape* makeClone(void) const ;

	

};
}// for namespace

