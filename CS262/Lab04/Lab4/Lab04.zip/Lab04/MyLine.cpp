#include "StdAfx.h"
#include "MyLine.h"
namespace macs262_labs{

/*
MyLine::MyLine(void){

}
*/

MyLine::MyLine(const MyLine* source){
	point1 = source->point1;
	point2 = source->point2;
	color = source->color;
}


MyShape* MyLine::makeClone() const{
	return new MyLine(this);
}

void MyLine::draw(System::Drawing::Graphics^g){
	System::Drawing::Pen^ pen = gcnew System::Drawing::Pen(color.getNetColor());
    g->DrawLine(pen, point1.getX(), point1.getY(), point2.getX(), point2.getY()); 
};


MyLine::~MyLine(void)
{

}
}//for namespace
