#pragma once
#include "MyShape.h"
namespace macs262_labs{
class MyOval : public MyShape
{
public:
	MyOval(void) : MyShape(point1, point2, color) {};
	MyOval(const MyOval* source);
	MyOval(Point p1, Point p2, Color rgb=Color(0,0,0), bool x=true);
	~MyOval(void);

	void setFilled(bool x);

	void draw(System::Drawing::Graphics^g) ;
	MyShape* makeClone(void) const;

private:
	bool filled;
};
}// for namespace

