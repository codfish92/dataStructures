#include "StdAfx.h"
#include "DrawList.h"
#include <assert.h>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
namespace macs262_labs{
DrawList::DrawList(void)
{
	capacity = DEAFAULT_CAPACITY;
	used = 0;
	current_index = 0;
	data = new value_type*[capacity];

}

void DrawList::insert(const value_type &x){ //  may need to move const
	if(capacity - used == 0){ // should always happen unless the default capacity has not been meet
		 reserved(2*used + 1);
		/*value_type **temp; // makes a new pointer for value_type
		temp = new value_type*[capacity +1 ]; // will make an array that is one bigger than the current one
		for(std::size_t i = 0; i < capacity; i++){
			temp[i] = data[i]; // will copy over all value_types to the same index in the new array
			delete data[i]; // should delete the value_type that was stored there

		}
		temp[capacity + 1] = new value_type(x); // will insert the new value_type into the now empty slot
		data = temp; // makes data point to the same array
		capacity++; // increases the capacity
		*/
		
		 data[used] = new value_type(x);

		used++; // increases the used
	}// ends if
	else{
		
		data[used] = new value_type(x) ;
		used++;
	}
}

void DrawList::remove_last(){
	assert(used != 0);
	/*if((capacity - used == 0) && (capacity > 0)){ //should always happen, unless there are less than the default capacity 
		value_type **temp; // makes a new pointer of value_types
		temp = new value_type*[capacity - 1]; // makes temp have an array of value_types one less than data
		for(std::size_t i = 0; i < capacity - 1; i ++){
			temp[i] = data[i]; // will copy over all the data save for the one being removed
			delete data[i]; // will delete the value_type in that array
		}
		delete data[capacity - 1]; // will delete the value_type to be removed
		data = temp; // makes data point to the same array as temp
		
		capacity--; // decrement capacity
		used--; // decrement used
	}
	/*else{
		cout << "did not always have a full array! could be that you haven't passed default capacity yet" << endl; // for debugging
		delete data[used -1];

	}*/
	
		delete data[used-1];
		used--;
}

std::size_t DrawList::size(){
	return used + 1;
}

void DrawList::begin(){
	current_index = 0;
}
bool DrawList::end(){
	if (current_index >= used){
		return true;
	}
	else{
		return false;
	}
}

void DrawList::operator ++(){
	current_index++;
}

DrawList::value_type* DrawList::operator *(){
	assert(!end());
	return data[current_index];
}
void DrawList::reserved(std::size_t x){
	value_type **temp;
	temp = new value_type*[x];
	
	for(std::size_t i = 0; i < (2*used+1); i++){
		temp[i] = NULL;
	} // ends for
	
	std::copy(data,data + used, temp);
	delete data;
	data = temp;
	capacity = 2*used+1;

}


DrawList::~DrawList(void)
{
	for(std::size_t i = 0; i < capacity; i++){
		delete [] data [i];
		
	}
	delete [] data;
} //not sure if needed
}// for namespace